package com.example.vo;

import com.example.entity.UserInfo;

public class UserInfoVo extends UserInfo {



}